import "./App.css"
import Transitionnew from "./Transitionnew";

const About = () => {
    return (
        <>
        <div className="container"> 
            <h1>ABout Is</h1>
        </div>
        </>
    );
}

export default Transitionnew(About);