export default function Home(){
    return (
        <>
        <p>Home</p>
        </>
    )
}