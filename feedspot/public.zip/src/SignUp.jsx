import Transitionnew from "./Transitionnew";

const SignUp= () => {
    return (
        <>
        <div className="container"> 
            <h1>Sign Up</h1>
        </div>
        </>
    )
}

export default Transitionnew(SignUp);